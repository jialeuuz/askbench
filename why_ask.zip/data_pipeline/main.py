import asyncio
import json
import os
from typing import List, Dict, Any

# 导入我们自己的模块
from post_api import CustomAPI
from prompt_loader import load_prompts
import strategies # 假设你的策略函数都在 strategies.py 中

# ==============================================================================
# --- Pipeline 核心逻辑 ---
# ==============================================================================

def load_jsonl(file_path: str) -> List[Dict[str, Any]]:
    """从jsonl文件加载数据"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            data = [json.loads(line) for line in f]
        print(f"成功从 '{file_path}' 加载了 {len(data)} 条数据。")
        return data
    except FileNotFoundError:
        print(f"错误: 输入文件 '{file_path}' 未找到。程序终止。")
        exit()

def save_jsonl(data: List[Dict[str, Any]], file_path: str):
    """将数据保存到jsonl文件"""
    # ### 优化点 1 改动 ###: 增加空数据检查
    if not data:
        print(f"没有数据可保存到 '{file_path}'。")
        return
    
    # 确保目录存在
    os.makedirs(os.path.dirname(file_path), exist_ok=True)
    with open(file_path, 'w', encoding='utf-8') as f:
        for item in data:
            f.write(json.dumps(item, ensure_ascii=False) + '\n')
    print(f"成功将 {len(data)} 条数据保存到 '{file_path}'。")


async def main(
    strategy: str,
    input_file: str,
    output_file: str,
    prompts_file: str,
    api_urls: List[str],
    api_type: str,
    api_token: str,
    max_concurrent_requests: int,
    timeout: int
):
    """
    数据构建 Pipeline 主函数，接收所有配置作为参数。
    """
    print("--- Pipeline 开始执行 ---")
    print(f"策略: {strategy}")
    print(f"输入: {input_file}")
    print(f"输出: {output_file}")
    print("--------------------------")

    # 1. 加载 Prompt 模板
    templates = load_prompts(prompts_file)

    # 2. 加载原始数据
    initial_data = load_jsonl(input_file)

    # 3. 初始化 API 客户端
    api_client = CustomAPI(
        url=api_urls[0],
        api_urls=api_urls,
        sk_token=api_token,
        api_type=api_type,
        timeout=timeout
    )

    # 4. 动态选择并获取策略函数
    strategy_func = getattr(strategies, strategy, None)
    if not strategy_func or not callable(strategy_func):
        print(f"错误: 策略 '{strategy}' 在 strategies.py 中未找到或不是一个可调用函数。")
        available_strategies = [s for s in dir(strategies) if callable(getattr(strategies, s)) and not s.startswith("__")]
        print(f"可用策略: {available_strategies}")
        return

    # 5. 执行策略
    print(f"正在执行策略 '{strategy}'，最大并发数: {max_concurrent_requests}...")
    
    original_infer_batch = api_client.infer_batch_async
    async def configured_infer_batch(*args, **kwargs):
        if 'max_concurrent' not in kwargs:
            kwargs['max_concurrent'] = max_concurrent_requests
        return await original_infer_batch(*args, **kwargs)
    api_client.infer_batch_async = configured_infer_batch
    
    # ### 优化点 1 改动 ###: 接收两个返回列表
    completed_data, failed_data = await strategy_func(
        api_client=api_client,
        data=initial_data,
        templates=templates
    )

    # 6. 保存结果
    # 保存成功的数据
    save_jsonl(completed_data, output_file)
    
    # 生成失败数据的文件名，例如 "output/test.jsonl" -> "output/test_failed.jsonl"
    if failed_data:
        base, ext = os.path.splitext(output_file)
        failed_output_file = f"{base}_failed{ext}"
        save_jsonl(failed_data, failed_output_file)
    
    print("--- Pipeline 执行完毕！ ---")


if __name__ == "__main__":
    STRATEGY = "generate_multi_turn_training_data"
    INPUT_FILE = "/lpai/volumes/base-mindgpt-ali-sh-mix/zhaojiale/why_ask/data/useless/math_sample_20k.jsonl"
    OUTPUT_FILE = "/lpai/volumes/base-mindgpt-ali-sh-mix/zhaojiale/why_ask/data/train_data/degrade_math_sample_20k_oss120_high.jsonl"
    API_URLS = ["http://10.80.13.242:8012/v1/chat/completions"]
    API_TYPE = "default"
    API_TOKEN = "none"
    PROMPTS_FILE = "prompts.txt"
    MAX_CONCURRENT_REQUESTS = 200
    TIMEOUT = 600
    
    asyncio.run(main(
        strategy=STRATEGY,
        input_file=INPUT_FILE,
        output_file=OUTPUT_FILE,
        prompts_file=PROMPTS_FILE,
        api_urls=API_URLS,
        api_type=API_TYPE,
        api_token=API_TOKEN,
        max_concurrent_requests=MAX_CONCURRENT_REQUESTS,
        timeout=TIMEOUT
    ))